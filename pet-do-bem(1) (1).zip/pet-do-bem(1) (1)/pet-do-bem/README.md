# Pet do Bem — versão com backend

## Alterações feitas
- Removidos todos os pets pré-cadastrados.
- Mantido o mesmo estilo visual do protótipo.
- Mais presença de rosa usando a cor da identidade visual em áreas do site, sem alterar as cores dos botões.
- Título “Encontre um novo melhor amigo...” em preto; “lar” continua vermelho.
- Cadastro de pet conectado ao backend.
- Pets salvos em `data/pets.json`.
- Todos os visitantes da mesma aplicação/servidor veem os pets cadastrados.
- Exclusão de pet também é persistida.

## Executar no Windows
No terminal, dentro desta pasta:

```bash
npm start
```

Depois acesse:

`http://localhost:3000`

Não abra o `index.html` diretamente com duplo clique, pois o cadastro usa a API do backend.

## Publicar na internet
Hospede esta pasta em um servidor que execute Node.js e mantenha `data/pets.json` em armazenamento persistente. Assim, todos os visitantes do endereço público verão os mesmos pets.

## Imagens
A foto escolhida no cadastro é enviada como Data URL e fica armazenada no JSON. Para produção em escala, recomenda-se usar armazenamento de imagens e guardar somente a URL no banco.

## Fluxo de adoção pelo WhatsApp
- O visitante não precisa criar conta nem fazer login.
- Ao abrir o perfil de um pet, aparecem foto(s), descrição, localização e informações do animal.
- O botão `Quero Adotar` abre um formulário com nome e dados de endereço/moradia do interessado.
- Ao enviar, o site abre o WhatsApp para o número responsável pela adoção com uma mensagem automática contendo o pet e os dados preenchidos.
- A mensagem inclui o endereço público da foto do pet para facilitar a visualização no WhatsApp.

> Observação: o link padrão do WhatsApp (`wa.me`) permite preencher automaticamente o texto, mas não consegue anexar uma imagem como arquivo na conversa. Para anexar a foto automaticamente seria necessária uma integração própria com a API do WhatsApp Business.
