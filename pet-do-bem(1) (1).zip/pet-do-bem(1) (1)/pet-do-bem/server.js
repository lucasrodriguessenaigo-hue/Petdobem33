const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const DATA_FILE = path.join(DATA_DIR, 'pets.json');
const UPLOADS_DIR = path.join(ROOT, 'uploads');
const INDEX_FILE = path.join(ROOT, 'index.html');

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOADS_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]', 'utf8');

function readPets() {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    const pets = JSON.parse(raw);
    return Array.isArray(pets) ? pets : [];
  } catch {
    return [];
  }
}

function writePets(pets) {
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(pets, null, 2), 'utf8');
  fs.renameSync(tmp, DATA_FILE);
}

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS'
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (Buffer.byteLength(body, 'utf8') > 15 * 1024 * 1024) {
        reject(new Error('Payload muito grande.'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { reject(new Error('JSON inválido.')); }
    });
    req.on('error', reject);
  });
}

function saveDataUrlImage(dataUrl, id) {
  const match = String(dataUrl || '').match(/^data:image\/(png|jpe?g|webp|gif);base64,(.+)$/i);
  if (!match) return '';
  const ext = match[1].toLowerCase().replace('jpeg','jpg');
  const filename = `${id}.${ext}`;
  fs.writeFileSync(path.join(UPLOADS_DIR, filename), Buffer.from(match[2], 'base64'));
  return `/uploads/${filename}`;
}

function deletePetImage(img) {
  if (!img || !img.startsWith('/uploads/')) return;
  const filename = path.basename(img);
  const target = path.join(UPLOADS_DIR, filename);
  if (target.startsWith(UPLOADS_DIR) && fs.existsSync(target)) fs.unlinkSync(target);
}

function sanitizePet(input) {
  const text = value => String(value ?? '').trim().slice(0, 5000);
  return {
    nome: text(input.nome) || 'Sem nome',
    especie: text(input.especie) || 'Cachorro',
    raca: text(input.raca) || 'SRD',
    sexo: text(input.sexo) || 'Não informado',
    idade: text(input.idade) || 'Não informado',
    porte: text(input.porte) || 'Não informado',
    cidade: text(input.cidade) || 'Não informado',
    estado: text(input.estado) || 'Não informado',
    status: text(input.status) || 'Para adoção',
    castrado: Boolean(input.castrado),
    vacinado: Boolean(input.vacinado),
    vermifugado: Boolean(input.vermifugado),
    peso: text(input.peso) || 'Não informado',
    cor: text(input.cor) || 'Não informado',
    microchip: Boolean(input.microchip),
    temperamento: text(input.temperamento) || 'O tutor ainda não adicionou uma descrição.',
    cadastro: text(input.cadastro) || new Date().toLocaleDateString('pt-BR'),
    img: text(input.img),
    userAdded: true
  };
}

function serveIndex(res) {
  fs.readFile(INDEX_FILE, (err, data) => {
    if (err) return sendJson(res, 500, {error:'Não foi possível carregar o site.'});
    res.writeHead(200, {'Content-Type':'text/html; charset=utf-8'});
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS'
    });
    return res.end();
  }

  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

  if (req.method === 'GET' && url.pathname === '/api/pets') {
    return sendJson(res, 200, {pets: readPets()});
  }

  if (req.method === 'POST' && url.pathname === '/api/pets') {
    try {
      const input = await readBody(req);
      const pets = readPets();
      const id = crypto.randomUUID();
      const pet = sanitizePet(input);
      pet.id = id;

      // A foto escolhida no formulário chega como Data URL.
      // Salvamos o arquivo no servidor e guardamos somente a URL no JSON.
      if (String(input.img || '').startsWith('data:image/')) {
        const savedImage = saveDataUrlImage(input.img, id);
        if (!savedImage) return sendJson(res, 400, {error:'Formato de imagem não suportado.'});
        pet.img = savedImage;
      }
      pets.unshift(pet);
      writePets(pets);
      return sendJson(res, 201, {pet});
    } catch (err) {
      return sendJson(res, 400, {error: err.message || 'Erro ao salvar o pet.'});
    }
  }

  const deleteMatch = url.pathname.match(/^\/api\/pets\/([^/]+)$/);
  if (req.method === 'DELETE' && deleteMatch) {
    const id = decodeURIComponent(deleteMatch[1]);
    const pets = readPets();
    const pet = pets.find(p => String(p.id) === id);
    const next = pets.filter(p => String(p.id) !== id);
    if (next.length === pets.length) return sendJson(res, 404, {error:'Pet não encontrado.'});
    deletePetImage(pet && pet.img);
    writePets(next);
    return sendJson(res, 200, {ok:true});
  }

  if (req.method === 'GET' && url.pathname.startsWith('/uploads/')) {
    const filename = path.basename(decodeURIComponent(url.pathname.slice('/uploads/'.length)));
    const file = path.join(UPLOADS_DIR, filename);
    if (!file.startsWith(UPLOADS_DIR) || !fs.existsSync(file)) {
      return sendJson(res, 404, {error:'Imagem não encontrada.'});
    }
    const ext = path.extname(file).toLowerCase();
    const types = {'.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.webp':'image/webp','.gif':'image/gif'};
    res.writeHead(200, {'Content-Type': types[ext] || 'application/octet-stream', 'Cache-Control':'public, max-age=31536000, immutable'});
    return fs.createReadStream(file).pipe(res);
  }

  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
    return serveIndex(res);
  }

  if (req.method === 'GET' && url.pathname === '/health') {
    return sendJson(res, 200, {ok:true});
  }

  res.writeHead(404, {'Content-Type':'text/plain; charset=utf-8'});
  res.end('Not found');
});

server.listen(PORT, () => {
  console.log(`Pet do Bem rodando em http://localhost:${PORT}`);
  console.log(`Dados dos pets: ${DATA_FILE}`);
});
